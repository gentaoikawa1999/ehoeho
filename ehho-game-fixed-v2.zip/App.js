import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Animated, Dimensions, SafeAreaView } from 'react-native';
import { StatusBar } from 'expo-status-bar';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

// ゲーム設定
const GAME_SPEED = 3; // ゲームの基本速度
const GRAVITY = 0.5; // 重力
const JUMP_FORCE = -10; // ジャンプ力
const GROUND_HEIGHT = 50; // 地面の高さ
const CHARACTER_SIZE = 80; // キャラクターのサイズ
const ITEM_SIZE = 40; // アイテムのサイズ
const OBSTACLE_SIZE = 40; // 障害物のサイズ
const SPAWN_RATE = 60; // アイテム生成レート（フレーム数）
const GOAL_DISTANCE = 5000; // ゴールまでの距離

export default function App() {
  // ゲーム状態
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [gamePaused, setGamePaused] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [distance, setDistance] = useState(0);
  const [combo, setCombo] = useState(0);
  
  // キャラクター状態
  const characterPositionY = useRef(new Animated.Value(windowHeight - GROUND_HEIGHT - CHARACTER_SIZE)).current;
  const [characterVelocity, setCharacterVelocity] = useState(0);
  const [isJumping, setIsJumping] = useState(false);
  const [isInvincible, setIsInvincible] = useState(false);
  const [characterFrame, setCharacterFrame] = useState(0);
  
  // アイテムと障害物
  const [tsubuAns, setTsubuAns] = useState([]);
  const [koshiAns, setKoshiAns] = useState([]);
  const [obstacles, setObstacles] = useState([]);
  
  // 背景スクロール
  const [backgroundPosition, setBackgroundPosition] = useState(0);
  
  // アニメーション
  const animationFrame = useRef(0);
  const lastFrameTime = useRef(0);
  const spawnCounter = useRef(0);
  const gameLoopId = useRef(null);
  
  // ゲーム開始
  const startGame = () => {
    console.log("Game started");
    setGameStarted(true);
    setGameOver(false);
    setGamePaused(false);
    setScore(0);
    setLives(3);
    setDistance(0);
    setCombo(0);
    setTsubuAns([]);
    setKoshiAns([]);
    setObstacles([]);
    setBackgroundPosition(0);
    characterPositionY.setValue(windowHeight - GROUND_HEIGHT - CHARACTER_SIZE);
    setCharacterVelocity(0);
    setIsJumping(false);
    setIsInvincible(false);
    animationFrame.current = 0;
    lastFrameTime.current = Date.now();
    spawnCounter.current = 0;
    
    if (gameLoopId.current) {
      cancelAnimationFrame(gameLoopId.current);
    }
    
    gameLoopId.current = requestAnimationFrame(gameLoop);
  };
  
  // ゲームオーバー
  const endGame = () => {
    console.log("Game over");
    setGameOver(true);
    if (score > highScore) {
      setHighScore(score);
    }
    
    if (gameLoopId.current) {
      cancelAnimationFrame(gameLoopId.current);
      gameLoopId.current = null;
    }
  };
  
  // ジャンプ
  const jump = () => {
    console.log("Jump triggered");
    if (!isJumping && gameStarted && !gameOver && !gamePaused) {
      console.log("Jumping");
      setIsJumping(true);
      setCharacterVelocity(JUMP_FORCE);
    }
  };
  
  // アイテム生成
  const spawnItems = () => {
    spawnCounter.current++;
    
    if (spawnCounter.current >= SPAWN_RATE) {
      spawnCounter.current = 0;
      
      // つぶあん生成
      if (Math.random() < 0.6) {
        const newTsubuAn = {
          id: Date.now() + 'tsubu',
          x: windowWidth + ITEM_SIZE,
          y: Math.random() * (windowHeight - GROUND_HEIGHT - ITEM_SIZE * 2) + ITEM_SIZE,
          size: ITEM_SIZE,
          isSuperItem: Math.random() < 0.1, // 10%の確率で特大つぶあん
        };
        setTsubuAns(prev => [...prev, newTsubuAn]);
      }
      
      // こしあん生成
      if (Math.random() < 0.4) {
        const newKoshiAn = {
          id: Date.now() + 'koshi',
          x: windowWidth + ITEM_SIZE,
          y: Math.random() * (windowHeight - GROUND_HEIGHT - ITEM_SIZE * 2) + ITEM_SIZE,
          size: ITEM_SIZE,
        };
        setKoshiAns(prev => [...prev, newKoshiAn]);
      }
      
      // 障害物生成
      if (Math.random() < 0.3) {
        const newObstacle = {
          id: Date.now() + 'obs',
          x: windowWidth + OBSTACLE_SIZE,
          y: windowHeight - GROUND_HEIGHT - OBSTACLE_SIZE,
          size: OBSTACLE_SIZE,
        };
        setObstacles(prev => [...prev, newObstacle]);
      }
    }
  };
  
  // 衝突判定
  const checkCollisions = () => {
    const charX = windowWidth / 4;
    const charY = characterPositionY._value;
    
    // つぶあんとの衝突
    setTsubuAns(prev => {
      const updatedTsubuAns = [...prev];
      let collisionOccurred = false;
      
      for (let i = updatedTsubuAns.length - 1; i >= 0; i--) {
        const item = updatedTsubuAns[i];
        const isColliding = 
          charX < item.x + item.size &&
          charX + CHARACTER_SIZE > item.x &&
          charY < item.y + item.size &&
          charY + CHARACTER_SIZE > item.y;
        
        if (isColliding) {
          // つぶあんゲット
          updatedTsubuAns.splice(i, 1);
          collisionOccurred = true;
          
          // スコア加算
          const pointsToAdd = item.isSuperItem ? 50 : 10;
          const comboMultiplier = Math.max(1, combo);
          setScore(prev => prev + pointsToAdd * comboMultiplier);
          
          // コンボ増加
          setCombo(prev => prev + 1);
          
          // 特大つぶあんの効果
          if (item.isSuperItem) {
            setIsInvincible(true);
            setTimeout(() => setIsInvincible(false), 5000); // 5秒間無敵
          }
        }
      }
      
      if (!collisionOccurred) {
        // コンボリセット（一定時間つぶあんを取らなかった場合）
        // setCombo(0);
      }
      
      return updatedTsubuAns;
    });
    
    // こしあんとの衝突
    if (!isInvincible) {
      setKoshiAns(prev => {
        const updatedKoshiAns = [...prev];
        
        for (let i = updatedKoshiAns.length - 1; i >= 0; i--) {
          const item = updatedKoshiAns[i];
          const isColliding = 
            charX < item.x + item.size &&
            charX + CHARACTER_SIZE > item.x &&
            charY < item.y + item.size &&
            charY + CHARACTER_SIZE > item.y;
          
          if (isColliding) {
            // こしあんに当たった
            updatedKoshiAns.splice(i, 1);
            setLives(prev => {
              const newLives = prev - 1;
              if (newLives <= 0) {
                endGame();
              }
              return newLives;
            });
            setCombo(0); // コンボリセット
          }
        }
        
        return updatedKoshiAns;
      });
    }
    
    // 障害物との衝突
    if (!isInvincible) {
      setObstacles(prev => {
        const updatedObstacles = [...prev];
        
        for (let i = updatedObstacles.length - 1; i >= 0; i--) {
          const obstacle = updatedObstacles[i];
          const isColliding = 
            charX < obstacle.x + obstacle.size &&
            charX + CHARACTER_SIZE > obstacle.x &&
            charY < obstacle.y + obstacle.size &&
            charY + CHARACTER_SIZE > obstacle.y;
          
          if (isColliding) {
            // 障害物に当たった
            updatedObstacles.splice(i, 1);
            setLives(prev => {
              const newLives = prev - 1;
              if (newLives <= 0) {
                endGame();
              }
              return newLives;
            });
            setCombo(0); // コンボリセット
          }
        }
        
        return updatedObstacles;
      });
    }
  };
  
  // ゲームループ
  const gameLoop = () => {
    if (!gameStarted || gameOver || gamePaused) return;
    
    const now = Date.now();
    const deltaTime = now - lastFrameTime.current;
    lastFrameTime.current = now;
    
    // フレームレート制御（約60FPS）
    if (deltaTime < 16) {
      gameLoopId.current = requestAnimationFrame(gameLoop);
      return;
    }
    
    // キャラクターアニメーション
    animationFrame.current++;
    if (animationFrame.current % 10 === 0) {
      setCharacterFrame(prev => (prev + 1) % 3);
    }
    
    // 背景スクロール
    setBackgroundPosition(prev => prev - GAME_SPEED);
    
    // 距離更新
    setDistance(prev => {
      const newDistance = prev + GAME_SPEED;
      if (newDistance >= GOAL_DISTANCE) {
        // ゴール到達
        endGame();
      }
      return newDistance;
    });
    
    // キャラクター物理演算
    setCharacterVelocity(prev => prev + GRAVITY);
    characterPositionY.setValue(Math.min(
      windowHeight - GROUND_HEIGHT - CHARACTER_SIZE,
      characterPositionY._value + characterVelocity
    ));
    
    // 地面に着地したらジャンプ状態解除
    if (characterPositionY._value >= windowHeight - GROUND_HEIGHT - CHARACTER_SIZE) {
      setIsJumping(false);
      setCharacterVelocity(0);
      characterPositionY.setValue(windowHeight - GROUND_HEIGHT - CHARACTER_SIZE);
    }
    
    // アイテム生成
    spawnItems();
    
    // アイテム移動
    setTsubuAns(prev => prev.map(item => ({
      ...item,
      x: item.x - GAME_SPEED
    })).filter(item => item.x > -ITEM_SIZE));
    
    setKoshiAns(prev => prev.map(item => ({
      ...item,
      x: item.x - GAME_SPEED
    })).filter(item => item.x > -ITEM_SIZE));
    
    setObstacles(prev => prev.map(obstacle => ({
      ...obstacle,
      x: obstacle.x - GAME_SPEED
    })).filter(obstacle => obstacle.x > -OBSTACLE_SIZE));
    
    // 衝突判定
    checkCollisions();
    
    gameLoopId.current = requestAnimationFrame(gameLoop);
  };
  
  // クリーンアップ
  useEffect(() => {
    return () => {
      if (gameLoopId.current) {
        cancelAnimationFrame(gameLoopId.current);
      }
    };
  }, []);
  
  // フクロウキャラクターのレンダリング
  const renderOwl = () => {
    return (
      <View style={styles.owlCharacter}>
        <View style={styles.owlBody}>
          <View style={styles.owlFace}>
            <View style={styles.owlEyes}>
              <View style={styles.owlEye} />
              <View style={styles.owlEye} />
            </View>
            <View style={styles.owlBeak} />
          </View>
        </View>
        {/* 足のアニメーション */}
        <View style={styles.owlFeet}>
          <View style={[styles.owlFoot, characterFrame === 1 ? styles.owlFootUp : null]} />
          <View style={[styles.owlFoot, characterFrame === 2 ? styles.owlFootUp : null]} />
        </View>
      </View>
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      
      {!gameStarted ? (
        // スタート画面
        <View style={styles.startScreen}>
          <Text style={styles.title}>えっほえっほ{'\n'}伝えなきゃゲーム</Text>
          <View style={styles.owlContainer}>
            {renderOwl()}
          </View>
          <TouchableOpacity style={styles.startButton} onPress={startGame}>
            <Text style={styles.startButtonText}>スタート</Text>
          </TouchableOpacity>
          {highScore > 0 && (
            <Text style={styles.highScore}>ハイスコア: {highScore}</Text>
          )}
        </View>
      ) : (
        // ゲーム画面
        <TouchableOpacity 
          style={styles.gameScreen} 
          activeOpacity={1}
          onPress={jump}
        >
          {/* 背景 */}
          <View style={styles.background}>
            {/* 背景の雲 */}
            {Array.from({ length: 5 }).map((_, i) => (
              <View 
                key={`cloud-${i}`} 
                style={[
                  styles.cloud,
                  {
                    left: ((backgroundPosition / 2) % windowWidth) + (i * windowWidth / 5),
                    top: 50 + (i * 30) % 100,
                    opacity: 0.6 + (i * 0.1) % 0.4,
                  }
                ]} 
              />
            ))}
            <View style={styles.ground} />
          </View>
          
          {/* UI */}
          <View style={styles.uiContainer}>
            <View style={styles.scoreContainer}>
              <Text style={styles.scoreText}>スコア: {score}</Text>
              {combo > 1 && (
                <Text style={styles.comboText}>{combo}コンボ!</Text>
              )}
            </View>
            
            <View style={styles.livesContainer}>
              {Array.from({ length: lives }).map((_, i) => (
                <View key={i} style={styles.lifeIcon} />
              ))}
            </View>
            
            <View style={styles.distanceContainer}>
              <Text style={styles.distanceText}>
                {Math.floor((distance / GOAL_DISTANCE) * 100)}%
              </Text>
            </View>
            
            <TouchableOpacity style={styles.pauseButton} onPress={() => setGamePaused(!gamePaused)}>
              <Text style={styles.pauseButtonText}>{gamePaused ? '▶' : '❚❚'}</Text>
            </TouchableOpacity>
          </View>
          
          {/* キャラクター */}
          <Animated.View 
            style={[
              styles.character, 
              { transform: [{ translateY: characterPositionY }] },
              isInvincible && styles.invincible
            ]}
          >
            {renderOwl()}
            <View style={styles.speechBubble}>
              <Text style={styles.speechText}>えっほえっほ</Text>
            </View>
          </Animated.View>
          
          {/* つぶあん */}
          {tsubuAns.map(item => (
            <View
              key={item.id}
              style={[
                styles.tsubuAn,
                item.isSuperItem && styles.superTsubuAn,
                {
                  left: item.x,
                  top: item.y,
                  width: item.size,
                  height: item.size,
                },
              ]}
            >
              <Text style={styles.anText}>粒</Text>
            </View>
          ))}
          
          {/* こしあん */}
          {koshiAns.map(item => (
            <View
              key={item.id}
              style={[
                styles.koshiAn,
                {
                  left: item.x,
                  top: item.y,
                  width: item.size,
                  height: item.size,
                },
              ]}
            >
              <Text style={styles.anText}>滑</Text>
            </View>
          ))}
          
          {/* 障害物 */}
          {obstacles.map(obstacle => (
            <View
              key={obstacle.id}
              style={[
                styles.obstacle,
                {
                  left: obstacle.x,
                  top: obstacle.y,
                  width: obstacle.size,
                  height: obstacle.size,
                },
              ]}
            >
              <Text>🚫</Text>
            </View>
          ))}
          
          {/* 一時停止画面 */}
          {gamePaused && (
            <View style={styles.pauseScreen}>
              <Text style={styles.pauseText}>一時停止中</Text>
              <TouchableOpacity style={styles.resumeButton} onPress={() => setGamePaused(false)}>
                <Text style={styles.resumeButtonText}>再開</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.quitButton} onPress={() => setGameStarted(false)}>
                <Text style={styles.quitButtonText}>タイトルに戻る</Text>
              </TouchableOpacity>
            </View>
          )}
          
          {/* ゲームオーバー画面 */}
          {gameOver && (
            <View style={styles.gameOverContainer}>
              {distance >= GOAL_DISTANCE ? (
                <>
                  <Text style={styles.gameOverText}>ゴール！</Text>
                  <Text style={styles.messageText}>アンパンマンはつぶあんって伝えた！</Text>
                </>
              ) : (
                <Text style={styles.gameOverText}>ゲームオーバー</Text>
              )}
              <Text style={styles.finalScoreText}>スコア: {score}</Text>
              <TouchableOpacity style={styles.restartButton} onPress={startGame}>
                <Text style={styles.restartButtonText}>もう一度</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.quitButton} onPress={() => setGameStarted(false)}>
                <Text style={styles.quitButtonText}>タイトルに戻る</Text>
              </TouchableOpacity>
            </View>
          )}
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  startScreen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#87CEEB',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  owlContainer: {
    width: 120,
    height: 120,
    marginBottom: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  startButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 30,
    elevation: 5,
  },
  startButtonText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  highScore: {
    marginTop: 20,
    fontSize: 18,
    color: '#333',
  },
  gameScreen: {
    flex: 1,
    backgroundColor: '#87CEEB',
  },
  background: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  cloud: {
    position: 'absolute',
    width: 100,
    height: 50,
    backgroundColor: 'white',
    borderRadius: 25,
  },
  ground: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: GROUND_HEIGHT,
    backgroundColor: '#8B4513',
  },
  uiContainer: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 10,
  },
  scoreContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
    borderRadius: 10,
  },
  scoreText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  comboText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF5722',
  },
  livesContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
    borderRadius: 10,
  },
  lifeIcon: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#F44336',
    marginHorizontal: 2,
  },
  distanceContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
    borderRadius: 10,
  },
  distanceText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  pauseButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 10,
    borderRadius: 10,
  },
  pauseButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  character: {
    position: 'absolute',
    width: CHARACTER_SIZE,
    height: CHARACTER_SIZE,
    left: windowWidth / 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  invincible: {
    shadowColor: '#FFD700',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
  },
  // フクロウキャラクターのスタイル
  owlCharacter: {
    width: CHARACTER_SIZE,
    height: CHARACTER_SIZE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  owlBody: {
    width: CHARACTER_SIZE * 0.8,
    height: CHARACTER_SIZE * 0.8,
    backgroundColor: 'white',
    borderRadius: CHARACTER_SIZE * 0.4,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#E0E0E0',
  },
  owlFace: {
    width: CHARACTER_SIZE * 0.6,
    height: CHARACTER_SIZE * 0.6,
    backgroundColor: 'white',
    borderRadius: CHARACTER_SIZE * 0.3,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#D2B48C',
  },
  owlEyes: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: CHARACTER_SIZE * 0.4,
  },
  owlEye: {
    width: CHARACTER_SIZE * 0.15,
    height: CHARACTER_SIZE * 0.15,
    backgroundColor: 'black',
    borderRadius: CHARACTER_SIZE * 0.075,
  },
  owlBeak: {
    width: CHARACTER_SIZE * 0.1,
    height: CHARACTER_SIZE * 0.05,
    backgroundColor: '#FFA500',
    borderRadius: CHARACTER_SIZE * 0.025,
    marginTop: CHARACTER_SIZE * 0.05,
  },
  owlFeet: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: CHARACTER_SIZE * 0.6,
    position: 'absolute',
    bottom: -CHARACTER_SIZE * 0.1,
  },
  owlFoot: {
    width: CHARACTER_SIZE * 0.1,
    height: CHARACTER_SIZE * 0.15,
    backgroundColor: '#D2B48C',
    borderRadius: CHARACTER_SIZE * 0.05,
  },
  owlFootUp: {
    transform: [{ translateY: -5 }],
  },
  speechBubble: {
    position: 'absolute',
    top: -30,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 5,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  speechText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  tsubuAn: {
    position: 'absolute',
    backgroundColor: '#E53935',
    borderRadius: ITEM_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  superTsubuAn: {
    backgroundColor: '#C62828',
    shadowColor: '#FFC107',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  koshiAn: {
    position: 'absolute',
    backgroundColor: '#8D6E63',
    borderRadius: ITEM_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  anText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  obstacle: {
    position: 'absolute',
    backgroundColor: 'rgba(33, 33, 33, 0.7)',
    borderRadius: OBSTACLE_SIZE / 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pauseScreen: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 20,
  },
  pauseText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 30,
  },
  resumeButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
    marginBottom: 20,
  },
  resumeButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  quitButton: {
    backgroundColor: '#F44336',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  quitButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  gameOverContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 20,
  },
  gameOverText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },
  messageText: {
    fontSize: 24,
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
  },
  finalScoreText: {
    fontSize: 24,
    color: 'white',
    marginBottom: 30,
  },
  restartButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
    marginBottom: 20,
  },
  restartButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
});
